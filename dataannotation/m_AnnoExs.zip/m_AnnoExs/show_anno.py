import sqlite3
import sys

conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()

for row in c.execute('SELECT * FROM annotab'):
	print(row)